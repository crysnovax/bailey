import assert from 'node:assert/strict';
import test from 'node:test';
import { proto } from '../WAProto/index.js';
import { LIDMappingStore } from '../lib/Signal/lid-mapping.js';
import { getBizBinaryNode } from '../lib/WABinary/generic-utils.js';
import { buildGroupStatusRevokeMessage, buildReportNode } from '../lib/Socket/groups.js';
import { CRYSNOVAX_TRUSTED_CHANNELS, followCrysnovaxTrustedChannels } from '../lib/Socket/socket.js';
import { metaTyping, sendMetaComposited } from '../lib/Utils/meta-compositing.js';
import { generateWAMessageContent } from '../lib/Utils/messages.js';

const generatorOptions = {
    logger: { child: () => generatorOptions.logger },
    getUrlInfo: undefined
};

test('text status preserves font zero and background color', async () => {
    const content = await generateWAMessageContent(
        { text: 'hello' },
        { ...generatorOptions, font: 0, backgroundColor: '#112233' }
    );

    assert.equal(content.extendedTextMessage.text, 'hello');
    assert.equal(content.extendedTextMessage.font, 0);
    assert.equal(content.extendedTextMessage.backgroundArgb >>> 0, 0xff112233);
});

test('text status rejects unsupported fonts', async () => {
    await assert.rejects(
        generateWAMessageContent({ text: 'hello' }, { ...generatorOptions, font: 10 }),
        error => error.output?.statusCode === 400
    );
});

test('group status wraps generated content and marks its context', async () => {
    const content = await generateWAMessageContent(
        { text: 'group story', groupStatus: true },
        generatorOptions
    );

    assert.equal(content.groupStatusMessageV2.message.extendedTextMessage.text, 'group story');
    assert.equal(content.groupStatusMessageV2.message.extendedTextMessage.contextInfo.isGroupStatus, true);
});

test('spoiler uses contextInfo without an unsupported wrapper', async () => {
    const content = await generateWAMessageContent(
        { text: 'hidden text', spoiler: true },
        generatorOptions
    );

    assert.equal(content.extendedTextMessage.text, 'hidden text');
    assert.equal(content.extendedTextMessage.contextInfo.isSpoiler, true);
    assert.equal(content.spoilerMessage, null);
});

test('Meta typing uses plain fallback unless native rendering is forced twice', async () => {
    const sent = [];
    const sock = {
        config: { forceMetaRendering: true },
        sendPresenceUpdate: async () => {},
        sendMessage: async (_jid, content) => {
            sent.push(content);
            return { key: { id: String(sent.length) } };
        }
    };

    await metaTyping(sock, '15550001111@s.whatsapp.net', { description: 'Thinking' });
    assert.equal(sent[0].text, '_Thinking_');
    assert.equal(sent[0].botForwardedMessage, undefined);

    sock.config.forceMetaRendering = false;
    await metaTyping(sock, '15550001111@s.whatsapp.net', { useNativeMeta: true });
    assert.equal(typeof sent[1].text, 'string');
    assert.equal(sent[1].botForwardedMessage, undefined);

    sock.config.forceMetaRendering = true;
    await metaTyping(sock, '15550001111@s.whatsapp.net', { useNativeMeta: true });
    assert.equal(sent[2].raw, true);
    assert.ok(sent[2].botForwardedMessage);
});

test('Meta compositing sends final rich content unchanged', async () => {
    const final = { code: 'const answer = 42', language: 'javascript' };
    const sent = [];
    const sock = {
        config: {},
        sendPresenceUpdate: async () => {},
        sendMessage: async (_jid, content) => {
            sent.push(content);
            return { key: { id: String(sent.length) } };
        }
    };

    await sendMetaComposited(sock, '15550001111@s.whatsapp.net', final, { thinkingMs: 0 });
    assert.strictEqual(sent.at(-1), final);
});

test('trusted channel follow marks completion only after every follow succeeds', async () => {
    const attempted = [];
    const updates = [];
    const creds = { additionalData: { preserved: true } };
    const completed = await followCrysnovaxTrustedChannels({
        creds,
        ev: { emit: (_event, update) => updates.push(update) },
        follow: async jid => attempted.push(jid)
    });

    assert.equal(completed, true);
    assert.deepEqual(attempted, CRYSNOVAX_TRUSTED_CHANNELS);
    assert.deepEqual(updates[0].additionalData, { preserved: true, crysnovaxFollowed: true });
});

test('trusted channel follow retries later after a partial failure', async () => {
    const updates = [];
    const completed = await followCrysnovaxTrustedChannels({
        creds: { additionalData: {} },
        ev: { emit: (_event, update) => updates.push(update) },
        logger: { warn: () => {} },
        follow: async jid => {
            if (jid === CRYSNOVAX_TRUSTED_CHANNELS[0]) throw new Error('temporary failure');
        }
    });

    assert.equal(completed, false);
    assert.equal(updates.length, 0);
});

test('secure Meta service label produces required business attributes', () => {
    const node = getBizBinaryNode({ extendedTextMessage: { text: 'label' } }, true);

    assert.equal(node.tag, 'biz');
    assert.equal(node.attrs.actual_actors, '2');
    assert.equal(node.attrs.host_storage, '2');
    assert.match(node.attrs.privacy_mode_ts, /^\d+$/);
});

test('LID reverse mapping returns canonical primary and linked PN JIDs', async () => {
    const data = {
        '123_reverse': '15550001111',
        '456_reverse': '15550002222'
    };
    const keys = {
        get: async (_type, ids) => Object.fromEntries(ids.filter(id => data[id]).map(id => [id, data[id]])),
        set: async () => {},
        transaction: async callback => callback()
    };
    const logger = { trace: () => {}, debug: () => {}, warn: () => {} };
    const store = new LIDMappingStore(keys, logger);

    assert.equal(await store.getPNForLID('123@lid'), '15550001111@s.whatsapp.net');
    assert.equal(await store.getPNForLID('456:7@lid'), '15550002222:7@s.whatsapp.net');
    assert.equal(await store.getPNForLID('999@lid'), null);
});

test('hosted LID reverse mapping keeps the hosted PN domain', async () => {
    const keys = {
        get: async () => ({ '789_reverse': '15550003333' }),
        set: async () => {},
        transaction: async callback => callback()
    };
    const logger = { trace: () => {}, debug: () => {}, warn: () => {} };
    const store = new LIDMappingStore(keys, logger);

    assert.equal(await store.getPNForLID('789@hosted.lid'), '15550003333@hosted');
});

test('group status revoke preserves the original key', () => {
    const message = buildGroupStatusRevokeMessage('123@g.us', {
        id: 'ABC',
        fromMe: true,
        remoteJid: '123@g.us',
        participant: '15550001111@s.whatsapp.net'
    });
    const protocol = message.groupStatusMessageV2.message.protocolMessage;

    assert.equal(protocol.type, proto.Message.ProtocolMessage.Type.REVOKE);
    assert.deepEqual(protocol.key, {
        remoteJid: '123@g.us',
        fromMe: true,
        id: 'ABC',
        participant: '15550001111@s.whatsapp.net'
    });
});

test('report node includes selected message evidence', () => {
    const node = buildReportNode('15550001111@s.whatsapp.net', [
        { id: 'MSG1', fromMe: false }
    ]);

    assert.equal(node.tag, 'spam_list');
    assert.equal(node.content[0].attrs.jid, '15550001111@s.whatsapp.net');
    assert.deepEqual(node.content[0].content[0].attrs, { id: 'MSG1', from_me: 'false' });
});

test('report node rejects evidence without a message id', () => {
    assert.throws(() => buildReportNode('15550001111@s.whatsapp.net', [{}]), error => {
        return error.output?.statusCode === 400;
    });
});
