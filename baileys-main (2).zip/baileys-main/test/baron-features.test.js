import assert from 'node:assert/strict';
import test from 'node:test';
import { proto } from '../WAProto/index.js';
import { extractAIGroupMetadata } from '../lib/Socket/aigroups.js';
import {
    generateCodeBlockContent,
    generateListContent,
    generateRichMessageContent,
    generateTableContent
} from '../lib/Utils/message-composer.js';
import { decodeConsumerApplication, consumerApplicationToMessage } from '../lib/Utils/consumer-application.js';
import { decodeGroupHistory, processGroupHistory } from '../lib/Utils/group-history.js';
import { normalizeMentionedJidsForSend } from '../lib/Utils/jid-display-normalization.js';
import {
    decodeDecryptedMsmsgMessage,
    decryptMsmsgBotMessage
} from '../lib/Utils/meta-ai-msmsg.js';
import { decodeE2eRekeyPayload } from '../lib/Utils/voip-rekey.js';
import {
    getMessageAddOns,
    getPollCorrectAnswer,
    getSenderLid,
    isScheduledMessage,
    toJid
} from '../lib/Utils/message-inspect.js';
import { makeCacheManagerAuthState } from '../lib/Store/make-cache-manager-store.js';
import { USyncQuery, USyncUser } from '../lib/WAUSync/index.js';

test('aiGroup metadata extraction marks groups as AI groups', () => {
    const result = {
        content: [
            {
                tag: 'create',
                content: [
                    {
                        tag: 'group',
                        attrs: {
                            id: '120363000000000000',
                            subject: 'AI Group',
                            s_t: '1700000000',
                            creation: '1699999999',
                            size: '2'
                        },
                        content: [
                            {
                                tag: 'participant',
                                attrs: {
                                    jid: '628123456789@s.whatsapp.net',
                                    type: 'admin'
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    };
    const meta = extractAIGroupMetadata(result);
    assert.equal(meta.id, '120363000000000000@g.us');
    assert.equal(meta.subject, 'AI Group');
    assert.equal(meta.isAIGroup, true);
    assert.equal(meta.participants.length, 1);
    assert.equal(meta.participants[0].admin, 'admin');
});

test('message composer builds bot forwarded table and code block content', () => {
    const table = generateTableContent('Comparison', ['Feature', 'A', 'B'], [['Speed', '1', '2']]);
    assert.ok(table.message.botForwardedMessage);
    const rich = table.message.botForwardedMessage.message.richResponseMessage;
    assert.equal(rich.messageType, 1);
    assert.equal(rich.submessages[0].messageType, 4);
    assert.equal(rich.submessages[0].tableMetadata.title, 'Comparison');
    assert.ok(rich.contextInfo.forwardedAiBotMessageInfo.botJid);

    const code = generateCodeBlockContent('const x = 1', undefined, { language: 'javascript' });
    assert.ok(code.message.botForwardedMessage);
    const codeRich = code.message.botForwardedMessage.message.richResponseMessage;
    assert.equal(codeRich.submessages[0].messageType, 5);
    assert.ok(codeRich.submessages[0].codeMetadata.codeBlocks.length > 0);
});

test('rich message generator returns bot forwarded message with context', () => {
    const generated = generateRichMessageContent(
        [{ messageType: 2, messageText: 'hi' }],
        { key: { id: 'q1' }, message: { conversation: 'q' } },
        {}
    );
    assert.ok(generated.message.botForwardedMessage);
    assert.equal(generated.message.botForwardedMessage.message.richResponseMessage.submessages[0].messageText, 'hi');
});

test('consumer application decode + revoke mapping', () => {
    const app = proto.ConsumerApplication.create({
        payload: {
            applicationData: {
                applicationContent: 'revoke',
                revoke: {
                    key: {
                        remoteJid: '628123456789@s.whatsapp.net',
                        id: 'ABC',
                        fromMe: true
                    }
                }
            }
        }
    });
    const buffer = proto.ConsumerApplication.encode(app).finish();
    const decoded = decodeConsumerApplication(buffer);
    const mapped = consumerApplicationToMessage(decoded);
    assert.equal(mapped.protocolMessage.type, proto.Message.ProtocolMessage.Type.REVOKE);
    assert.equal(mapped.protocolMessage.key.id, 'ABC');
});

test('group history decode round trips with message bytes', () => {
    const inner = proto.WebMessageInfo.create({
        key: { remoteJid: '628123456789@s.whatsapp.net', id: 'M1', fromMe: true },
        message: { conversation: 'hello' }
    });
    const gh = proto.GroupHistoryWithMessageBytes.create({
        messages: [{ messageBytes: proto.WebMessageInfo.encode(inner).finish() }]
    });
    const buffer = proto.GroupHistoryWithMessageBytes.encode(gh).finish();
    const decoded = decodeGroupHistory(buffer, { withMessageBytes: true });
    assert.equal(decoded.messages.length, 1);
    assert.equal(decoded.messages[0].message.conversation, 'hello');
    const processed = processGroupHistory(decoded);
    assert.equal(processed.messages.length, 1);
});

test('voip rekey payload decode maps key types', () => {
    const payload = proto.E2eRekeyPayload.create({
        keys: [
            {
                type: proto.RekeyKeyType.REKEY_KEY_AUDIO,
                key: Buffer.from([1, 2, 3])
            }
        ]
    });
    const buffer = proto.E2eRekeyPayload.encode(payload).finish();
    const decoded = decodeE2eRekeyPayload(buffer);
    assert.equal(decoded.keys[0].type, 'REKEY_KEY_AUDIO');
    assert.deepEqual(decoded.keys[0].key, Buffer.from([1, 2, 3]));
});

test('meta ai msmsg decryption requires message secret', async () => {
    await assert.rejects(
        decryptMsmsgBotMessage(undefined, { participant: 'x@c.us', meId: '1@lid' }, { encIv: Buffer.alloc(12), encPayload: Buffer.alloc(16) }),
        /Missing required messageSecret/
    );
    await assert.rejects(
        decryptMsmsgBotMessage(Buffer.alloc(32), undefined, { encIv: Buffer.alloc(12), encPayload: Buffer.alloc(16) }),
        /Missing required participant/
    );
});

test('meta ai msmsg decode tolerates unpadded messages', () => {
    const msg = proto.Message.create({ conversation: 'hi' });
    const decoded = decodeDecryptedMsmsgMessage(proto.Message.encode(msg).finish());
    assert.equal(decoded.conversation, 'hi');
});

test('jid normalization leaves PN jids untouched', async () => {
    const result = await normalizeMentionedJidsForSend(
        ['628123456789@s.whatsapp.net'],
        undefined,
        { lidMapping: { getPNForLID: async () => undefined } },
        undefined
    );
    assert.deepEqual(result, ['628123456789@s.whatsapp.net']);
});

test('message inspect helpers read metadata safely', () => {
    assert.equal(isScheduledMessage({ scheduledMessageMetadata: { scheduledTime: '1700000000' } }), true);
    assert.equal(isScheduledMessage({}), false);
    assert.equal(toJid('628123456789'), '628123456789@s.whatsapp.net');
    assert.equal(toJid('628123456789@s.whatsapp.net'), '628123456789@s.whatsapp.net');
    assert.equal(getPollCorrectAnswer({ pollCreationMessage: { pollType: 1, correctAnswer: { optionName: 'A' } } }), 'A');
    assert.equal(getPollCorrectAnswer({ pollCreationMessage: { pollType: 0 } }), null);
    assert.deepEqual(getMessageAddOns({ messageAddOns: [{ type: 1 }] }), [{ type: 1 }]);
    assert.deepEqual(getSenderLid({ key: { participantLid: '1234567890@lid' } }), { jid: '', lid: '1234567890@lid' });
    assert.deepEqual(getSenderLid({ key: { participant: '1234567890@lid' } }), { jid: '1234567890@lid', lid: '1234567890@lid' });
});

test('usync query builds username protocol queries', () => {
    const usync = new USyncQuery().withUsernameProtocol().withUser(new USyncUser().withUsername('baron'));
    assert.equal(usync.protocols[0].name, 'username');
    assert.equal(usync.protocols[0].getQueryElement().tag, 'username');
    const userEl = usync.users[0];
    assert.equal(userEl.username, 'baron');
    assert.equal(userEl.validate(), true);
});

test('usync query parses list results with contact protocol', () => {
    const usync = new USyncQuery().withContactProtocol();
    const result = {
        attrs: { type: 'result' },
        content: [
            {
                tag: 'usync',
                content: [
                    {
                        tag: 'list',
                        content: [
                            {
                                tag: 'user',
                                attrs: { jid: '628123456789@s.whatsapp.net' },
                                content: [{ tag: 'contact', attrs: { type: 'in' } }]
                            }
                        ]
                    }
                ]
            }
        ]
    };
    const parsed = usync.parseUSyncQueryResult(result);
    assert.equal(parsed.list.length, 1);
    assert.equal(parsed.list[0].id, '628123456789@s.whatsapp.net');
    assert.equal(parsed.list[0].contact, true);
});

test('cache manager auth state stores and reads creds', async () => {
    // Memory store — plain object compatible with cache-manager v7 createCache
    const memoryStore = () => {
        const data = new Map();
        return {
            async get(key) { return data.get(key); },
            async set(key, value) { data.set(key, value); },
            async delete(key) { data.delete(key); }, // Keyv API used by cache-manager v7
            async del(key) { data.delete(key); }, // legacy alias
            async keys(pattern) {
                const prefix = typeof pattern === 'string' ? pattern.replace(/\*$/, '') : '';
                return [...data.keys()].filter(k => !prefix || k.startsWith(prefix));
            },
            disconnect() {}
        };
    };
    const sharedStore = memoryStore();
    const authState = await makeCacheManagerAuthState(sharedStore, 'session-1');
    const me = { id: '628123456789:0@s.whatsapp.net' };
    authState.state.creds.me = me;
    await authState.saveCreds();

    // Different session key does not see the creds
    const other = await makeCacheManagerAuthState(memoryStore(), 'session-other');
    assert.notEqual(other.state.creds.me?.id, me.id);

    // Same session key + same store reloads the saved creds
    const authState2 = await makeCacheManagerAuthState(sharedStore, 'session-1');
    assert.equal(authState2.state.creds.me?.id, me.id);
    await authState2.clearState();
    const cleared = await makeCacheManagerAuthState(sharedStore, 'session-1');
    assert.notEqual(cleared.state.creds.me?.id, me.id);
});
